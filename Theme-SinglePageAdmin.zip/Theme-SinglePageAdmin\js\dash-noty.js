﻿	var n = noty({
		text: '<img src="assets/img/face36x36.jpg"> <strong>Marcel Newman</strong> <br /> Hi! Welcome. This is CUBES, the new Dashboard panel created for WrapBootstrap. Please take a look and enjoy.',
		type: 'alert',
		layout: 'topRight',
		closeWith: ['hover'],
	});



